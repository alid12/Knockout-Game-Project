/*************** Code in main file **************/
//Circle Shape to implement defence for player 1
	CircleShape circle(200);
	circle.setRadius(200);

	// change the number of sides (points) to 100
	circle.setPointCount(100);

	// make it semi-transparent 
	circle.setFillColor(sf::Color(255, 255, 255, 128));

	// smooth the shape 
	//circle.setSmooth(true);

	// where is the shape
	//Vector2f circle_position;
	//Vector2f circle_position2;

	//Circle Shape to implement defence for player 2
	CircleShape circle2(200);
	circle2.setRadius(200);

	// change the number of sides (points) to 100
	circle2.setPointCount(100);

	// make it semi-transparent 
	circle2.setFillColor(sf::Color(255, 255, 255, 128));
