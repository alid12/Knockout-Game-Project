/*********** Blaster Header File ********/
#pragma once
#include <SFML/Graphics.hpp>

class Blaster {
private:
	sf::RectangleShape blaster;

public:
	Blaster(sf::Vector2f size) {
		blaster.setSize(size);
		blaster.setFillColor(sf::Color::Red);
	}

	void fire(int speed) {
		blaster.move(speed, 0);
	}

	int getRight() {
		return blaster.getPosition().x + blaster.getSize().x;
	}

	int getLeft() {
		return blaster.getPosition().x;
	}

	int getTop() {
		return blaster.getPosition().y;
	}

	int getBottom() {
		return blaster.getPosition().y + blaster.getSize().y;
	}

	void draw(sf::RenderWindow& window) {
		window.draw(blaster);
	}

	void setPos(sf::Vector2f newPos) {
		blaster.setPosition(newPos);
	}


};

/******** Main Game code ********///Blaster class Objects
	std::vector<Blaster> blasterVec;
	bool isFiring = false;

/Collision detection between players based on attack types
			if ((player.getGlobalBound().intersects(player2.getGlobalBound())) && base_attack == true && base_attack2 == false && defense2 == false && ultimate2 == false)
			{
				player2.setHealth(20);
			}

			if ((player.getGlobalBound().intersects(player2.getGlobalBound())) && base_attack == true && base_attack2 == true)
			{
				player.setHealth(10);
				player2.setHealth(10);
			}

			if ((player.getGlobalBound().intersects(player2.getGlobalBound())) && base_attack == true && defense2 == true)
			{
				player2.setHealth(5);
			}

			if ((player.getGlobalBound().intersects(player2.getGlobalBound())) && base_attack == true && ultimate2 == true)
			{
				player.setHealth(60);
				player2.setHealth(10);
			}

			if (ultimate == true && base_attack2 == true)
			{
				for (int i = 0; i < blasterVec.size(); i++)
				{
					if (blasterVec[i].getRight() > player2.getCenter().x && blasterVec[i].getTop() > player2.getCenter().y && blasterVec[i].getBottom() < (player2.getCenter().y + 240))
					{
						player2.setHealth(60);
					}
				}
				if ((player2.getGlobalBound().intersects(player.getGlobalBound())) && base_attack2 == true && ultimate == true)
				{
					player.setHealth(10);
				}
			}
			if (ultimate == true && base_attack2 == false && defense2 == false && ultimate2 == false)
			{
				for (int i = 0; i < blasterVec.size(); i++)
				{
					if (blasterVec[i].getRight() > player2.getCenter().x && blasterVec[i].getTop() > player2.getCenter().y && blasterVec[i].getBottom() < (player2.getCenter().y + 240))
					{
						player2.setHealth(60);
					}
				}
			}

			if (ultimate == true && defense2 == true)
			{
				for (int i = 0; i < blasterVec.size(); i++)
				{
					if (blasterVec[i].getRight() > player2.getCenter().x && blasterVec[i].getTop() > player2.getCenter().y && blasterVec[i].getBottom() < (player2.getCenter().y + 240))
					{
						player2.setHealth(55);
					}
				}
			}

			if (ultimate == true && ultimate2 == true)
			{
				for (int i = 0; i < blasterVec.size(); i++)
				{
					if (blasterVec[i].getRight() > player2.getCenter().x && blasterVec[i].getTop() > player2.getCenter().y && blasterVec[i].getBottom() < (player2.getCenter().y + 240))
					{
						player2.setHealth(60);
					}
				}
				if (player2.getGlobalBound().intersects(player.getGlobalBound()))
				{
					player.setHealth(60);
				}
			}
			
			if (((player2.getGlobalBound().intersects(player.getGlobalBound())) == true) && (base_attack2 == true) && (base_attack == false) && (defense == false) && (ultimate == false))
			{
				player.setHealth(20);
			}

			if ((player2.getGlobalBound().intersects(player.getGlobalBound())) && base_attack2 == true && defense == true)
			{
				player.setHealth(5);
			}

			if ((player2.getGlobalBound().intersects(player.getGlobalBound())) && (ultimate2 == true) && (base_attack == false) && (defense == false) && (ultimate == false))
			{
				player.setHealth(60);
			}

			if ((player2.getGlobalBound().intersects(player.getGlobalBound())) && ultimate2 == true && defense == true)
			{
				player.setHealth(55);
			}

if (isFiring == true) {
				Blaster newBlaster(sf::Vector2f(25, 5));
				newBlaster.setPos(sf::Vector2f(player.getCenter().x + 170, player.getCenter().y + 60));
				blasterVec.push_back(newBlaster);
				isFiring = false;
			}

for (int i = 0; i < blasterVec.size(); i++) {
				blasterVec[i].draw(window);
				blasterVec[i].fire(3);
			}

/********* Code not used in main file ***********/
Sprite::Sprite(float startX, float startY)
{
    sf::Sprite characterSprite;
    sf::Texture textureSprite; 
    position.x = startX;
    position.y = startY;
    int stat_health=100;
    int max_health=0;
    
         
    characterSprite.setTexture(textureSprite);
    characterSprite.setSize(sf::Vector2f(50, 5));
    characterSprite.setOrigin(sf::Vector2f(0, 0));
    characterSprite.setPosition(position.x,position.y);
    FloatRect Sprite::getPosition()
    {
     return characterSprite.getGlobalBounds();
    }
 
}
Class Texture {
Texture textureBackground;
textureBackground.loadFromFile (background.png)

if(!textureBackground.loadFromFile("graphics/background.png"))
    {
        cout << "Error loading resource '::Texture'" << endl;
    }
    else
    {
        cout << "Texture Loaded" << endl;
    }


Texture textureSprite;
textureSprite.loadFromFile (sprite.png)

if(!textureSprite.loadFromFile("graphics/sprite.png"))
    {
        cout << "Error loading resource '::Texture'" << endl;
    }
    else
    {
        cout << "Texture Loaded" << endl;
    }
}


/******************Main code where collision was tested****************/
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Blaster.h"
#include "Player.h"
#include <vector>
int main()
{
// create the window
    sf::RenderWindow window(sf::VideoMode(800, 600), "Fighter Game");
    window.setKeyRepeatEnabled(true);

//Define Objects:
std::vector<Blaster> blasterVec;
bool firing = false;
  
      while (window.isOpen()) {

          sf::Event Event;
 
          //Event Loop:
          while (window.pollEvent(Event)) {
            // "close requested" event: we close the window
              switch (Event.type) {
 
              case sf::Event::Closed:
                  window.close();
                                      } 
                 int velocity = 6;

/*
The Key presses syntax given below has been written with the help of the https://www.sfml-dev.org/documentation/2.5.1/classsf_1_1Keyboard.php
and has been modified to this project*/

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {
				player.move(sf::Vector2f(0, -velocity));
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
				player.move(sf::Vector2f(0, velocity));
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {
				player.move(sf::Vector2f(-velocity, 0));
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {
				player.move(sf::Vector2f(velocity, 0));
			}

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
				firing = true;
			}


/*
End of the Key presses syntax given above that has been written with the help of the https://www.sfml-dev.org/documentation/2.5.1/classsf_1_1Keyboard.php
and has been modified to this project*/

       }
 

        // clear the window with black color
        window.clear(sf::Color::Black);
window.clear();
	
		if (isFiring == true) {
			Blaster newBlaster(sf::Vector2f(25, 5));
			newBlaster.setPos(sf::Vector2f(spritePlayer2.getPosition().x+170, spritePlayer2.getPosition().y+60));
			blasterVec.push_back(newBlaster);
			isFiring = false;
		}
for (int i = 0; i < blasterVec.size(); i++) {
			blasterVec[i].draw(window);
			blasterVec[i].fire(3);
		}

		for (int i = 0; i < blasterVec.size(); i++) {

			if (blasterVec[i].getRight() > spritePlayer.getPosition().x &&
				blasterVec[i].getTop() > spritePlayer.getPosition().y
				&& blasterVec[i].getBottom() < (spritePlayer.getPosition().y+240))
			{
				spritePlayer.setPosition(sf::Vector2f(4234432, 4234423));
			}
		}

        // draw everything here...
        // window.draw(...);

        // end the current frame
        window.display();
    }

    return 0;
}
   

/******************End of Main code where collision was tested****************/
 
/***************
The code given below has been written with the help of the tutorial: http://gamecodeschool.com/sfml/coding-a-simple-pong-game-with-sfml/
and has been modified to this project******************/

// keep object in bounds
    Float Swordman::getXVelocity()
    {
        return xVelocity;
    }
 
    void Swordman::reboundSides()
    {
        xVelocity = -xVelocity;
    }
 
    void Swordman::reboundBatOrTop()
    {
        position.y -= (yVelocity * 30);
        yVelocity = -yVelocity;
 
    }
 
    void Swordman::hitBottom()
    {
        position.y = 1;
        position.x = 500;
    }

    void Swordman::update()
    {
        // Update the ball position variables
        position.y += yVelocity;
        position.x += xVelocity;
 
        // Move the ball and the bat
        sprite.setPosition(position);
}
/***************
The end of the code that has been written with the help of the tutorial: http://gamecodeschool.com/sfml/coding-a-simple-pong-game-with-sfml/
and has been modified to this project
******************/

 
/***************Code was referenced from https://maksimdan.gitbooks.io/sfml-and-gamedevelopement/content/index.html  but but Menus were not used in the project ******************/

#pragma once


class Menu
{
public:
    Menu();
    ~Menu();
Menu::Menu(float width, float height)
{
    if (!font.loadFromFile("KeepCalm-Medium.otf"))
    {
        return;
    }

    menu[0].setFont(font);
    menu[0].setColor(sf::Color::Magenta);
    menu[0].setString("Play");
    menu[0].setPosition(sf::Vector2f(width / 2, height / (MAX_NUMBER_OF_ITMES + 1) * 1));

    menu[1].setFont(font);
    menu[1].setColor(sf::Color::White);
    menu[1].setString("Options");
    menu[1].setPosition(sf::Vector2f(width / 2, height / (MAX_NUMBER_OF_ITMES + 1) * 2));

    menu[2].setFont(font);
    menu[2].setColor(sf::Color::White);
    menu[2].setString("Exit");
    menu[2].setPosition(sf::Vector2f(width / 2, height / (MAX_NUMBER_OF_ITMES + 1) * 3));
}

};

/**************End of code referenced from https://maksimdan.gitbooks.io/sfml-and-gamedevelopement/content/index.html but Menus were not used in the project***********************/

