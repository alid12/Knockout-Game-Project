

#ifndef SFML_defense_HPP
#define SFML_defense_HPP

//header file for defense 
#include <SFML/Graphics.hpp>
#include "Private.hpp"
#include <vector>

namespace sf
{
class defense;

namespace priv
 // code of the defense
}
